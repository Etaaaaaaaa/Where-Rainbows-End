#ifndef LEVELPAGE_H
#define LEVELPAGE_H

#include <QMainWindow>
#include <QObject>

class Levelpage : public QMainWindow
{
    Q_OBJECT
public:
    explicit Levelpage(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *);


signals:

};

#endif // LEVELPAGE_H
