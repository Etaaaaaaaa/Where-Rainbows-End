#ifndef INTROSCENE_H
#define INTROSCENE_H

#include <QMainWindow>

class Introscene : public QMainWindow
{
    Q_OBJECT
public:
    explicit Introscene(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *);


signals:

};

#endif // INTROSCENE_H
