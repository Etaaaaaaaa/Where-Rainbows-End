#include "blue.h"


blue::blue(int x, int y)
{
    this->position_x=x;
    this->position_y=y;
    this->setblood(3);
}

void blue::setposition_x(int x)
{
    this->position_x=x;
}

void blue::setposition_y(int y)
{
    this->position_y=y;
}

void blue::setblood(int blood)
{
    this->blood=blood;
}

void blue::setstate(int state)
{
    this->state=state;
}

void blue::setdir(int dir)
{
    this->dir=dir;
}
