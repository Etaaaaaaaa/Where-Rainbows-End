#include "mainwindow.h"
#include<ReadyScene.h>
#include <QApplication>
#include<QSound>
#include<overscene.h>




int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
   /*Overscene o;
    o.show();
    */Readyscene w;
    w.move(500,200);
    w.setFixedSize(1200,800);
    w.show();

    return a.exec();
}
/*
                               _ooOoo_
                              o8888888o
                              88" . "88
                              (| -_- |)
                              O\  =  /O
                           ____/`---'\____
                         .'  \\|     |//  `.
                        /  \\|||  :  |||//  \
                       /  _||||| -:- |||||-  \
                       |   | \\\  -  /// |   |
                       | \_|  ''\---/''  |   |
                       \  .-\__  `-`  ___/-. /
                     ___`. .'  /--.--\  `. . __
                  ."" '<  `.___\_<|>_/___.'  >'"".
                 | | :  `- \`.;`\ _ /`;.`/ - ` : | |
                 \  \ `-.   \_ __\ /__ _/   .-` /  /
            ======`-.____`-.___\_____/___.-`____.-'======
                               `=---='
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                        佛祖保佑       永无BUG
*/
