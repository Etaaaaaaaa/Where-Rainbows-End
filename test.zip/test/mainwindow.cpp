#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QPainter>
#include<QKeyEvent>
#include<pink.h>
#include<blue.h>
#include<synchapi.h>
#include<mypushbutton.h>
#include<QPushButton>
#include<ReadyScene.h>
#include<QDebug>
#include<array.h>
#include<overscene.h>

pink p1(0,0);
blue p2(0,0);
int flag=1;
int live=0;


int map[30][20]={0};


//0表示空，1表示墙，2表示地刺，3表示金币，4表示血包，5表示出口1,6表示出口2



MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow)
{


    this->setWindowIcon(QPixmap(":/res/icon.png"));
    this->setWindowTitle("Where Rainbows End");




    ui->setupUi(this);
   /* for(int i=0;i<30;i++)
    {
        for(int j=0;j<20;j++)
        {
            map[i][j]=a.map1[i][j];
        }
    }
    */


}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *)
{
    setFixedSize(1200,800);
    this->setWindowTitle("Where Rainbows End");

    if(map_n==1)
    {
        p1.map_x=9;
        p1.map_y=0;
        p2.map_x=0;
        p2.map_y=12;
        p1.setposition_x(360);
        p1.setposition_y(0);
        p2.setposition_x(0);
        p2.setposition_y(480);

        Array tem(1);

        for(int i=0;i<30;i++)
        {
            for(int j=0;j<20;j++)
            {
               map[i][j]=tem.a[i][j];
            }
        }

        flag=0;
        map_n=0;


    }
    if(map_n==2)
    {
        p1.map_x=0;
        p1.map_y=1;
        p2.map_x=1;
        p2.map_y=19;
        p1.setposition_x(0);
        p1.setposition_y(40);
        p2.setposition_x(40);
        p2.setposition_y(760);

        Array tem(2);

        for(int i=0;i<30;i++)
        {
            for(int j=0;j<20;j++)
            {
               map[i][j]=tem.a[i][j];
            }
        }

        flag=0;
        map_n=0;


    }
    if(map_n==3)
    {
        p1.map_x=23;
        p1.map_y=0;
        p2.map_x=6;
        p2.map_y=19;
        p1.setposition_x(920);
        p1.setposition_y(0);
        p2.setposition_x(240);
        p2.setposition_y(760);

        Array tem(3);

        for(int i=0;i<30;i++)
        {
            for(int j=0;j<20;j++)
            {
               map[i][j]=tem.a[i][j];
            }
        }

        flag=0;
        map_n=0;


    }


    this->show();
    QPainter painter(this);
    QPixmap emap;
    QPixmap ppink;
    QPixmap pblue;
    QPixmap mapbrick;
    QPixmap coin;
    QPixmap heart;
    QPixmap exit1;
    QPixmap exit2;
    QPixmap bo;

    exit1.load(":/res/exit1.png");
    exit1=exit1.scaled(40,40);

    exit2.load(":/res/exit2.png");
    exit2=exit2.scaled(40,40);

    bo.load(":/res/bomb.png");
    bo=bo.scaled(40,40);


    coin.load(":/res/money.png");
    coin=coin.scaled(40,40);

    heart.load(":/res/heart.png");
    heart=heart.scaled(40,40);

    mapbrick.load(":/res/brick.png");
    mapbrick=mapbrick.scaled(40,40);

    emap.load(":/res/map.png");
    painter.drawPixmap(0,0,this->width(),this->height(),emap);



    for(int i=0;i<30;i++)
    {
        for(int j=0;j<20;j++)
        {//0表示空，1表示墙，2表示地刺，3表示金币，4表示血包，5表示出口1,6表示出口2，7入口1,8入口2
            if(map[i][j]==1)
            {
                painter.drawPixmap(i*40,j*40,40,40,mapbrick);
            }
            if(map[i][j]==2)
            {
                 painter.drawPixmap(i*40,j*40,40,40,bo);

            }
            if(map[i][j]==3)
            {
                painter.drawPixmap(i*40,j*40,40,40,coin);
            }
            if(map[i][j]==4)
            {
                painter.drawPixmap(i*40,j*40,40,40,heart);
            }
            if(map[i][j]==5)
            {
                painter.drawPixmap(i*40,j*40,40,40,exit1);
            }
            if(map[i][j]==6)
            {
                painter.drawPixmap(i*40,j*40,40,40,exit2);
            }




        }
    }


    ppink.load(":/res/pink.png");
    ppink = ppink.scaled(ppink.width()*0.8,ppink.height()*0.8);
    painter.drawPixmap( p1.position_x,p1.position_y,ppink.width(),ppink.height(),ppink);


    pblue.load(":/res/blue.png");
    pblue = pblue.scaled(pblue.width()*0.8,pblue.height()*0.8);
    painter.drawPixmap(p2.position_x,p2.position_y,pblue.width(),pblue.height(),pblue);

    if(this->LOSE()&&flag==0)
    {
        Overscene *o=new Overscene;
        o->score=Score;
        o->move(800,400);
         o->show();
         o->v=1;
        this->close();

        flag=1;



    }
    if(this->WIN()&&flag==0)
    {
        Overscene *o=new Overscene;
        o->score=Score;
         o->move(800,400);
         o->show();

         o->v=0;
        this->close();

        flag=1;

    }




}

void MainWindow::keyPressEvent(QKeyEvent *event)
{
    if(event->key()==Qt::Key_Escape)
    {
        this->close();
    }
    if(event->key()==Qt::Key_R)
    {
        this->Restart();
    }
    if(event->key()==Qt::Key_Up)
    {
        this->Up2();
    }
    if(event->key()==Qt::Key_Left)
    {
        this->Left2();//left和right里面有一个和箱子的判断
    }
    if(event->key()==Qt::Key_Right)
    {
        this->Right2();
    }
    if(event->key()==Qt::Key_Down)
    {
        this->Down2();
    }
    if(event->key()==Qt::Key_W)
    {
        this->Up1();
    }
    if(event->key()==Qt::Key_A)
    {
        this->Left1();//left和right里面有一个和箱子的判断
    }
    if(event->key()==Qt::Key_D)
    {
        this->Right1();
    }
    if(event->key()==Qt::Key_S)
    {
        this->Down1();
    }
    update();

}

void MainWindow::set1()
{
    this->map_n=1;
}

void MainWindow::set2()
{
    this->map_n=2;
}
void MainWindow::set3()
{
    this->map_n=3;
}

void MainWindow::Left1()
{
    if(map[p1.map_x-1][p1.map_y]!=1)
        if(p1.map_x>0)
        {
            p1.setdir(p1.LEFT);
            p1.setposition_x(p1.position_x-40);
            p1.map_x=p1.map_x-1;
        }

    if(judgeblock1())
        {
            map[p1.map_x][p1.map_y]=0;
            Score-=10;
        }
        if(judgemoney1())
        {
            map[p1.map_x][p1.map_y]=0;
            Score+=1;
        }
        if(judgeblood1())
        {
            map[p1.map_x][p1.map_y]=0;
            Score+=2;
        }
}
void MainWindow::Right1()
{
    if(map[p1.map_x+1][p1.map_y]!=1)
        if(p1.map_x<29)
        {
            p1.setdir(p1.RIGHT);
            p1.setposition_x(p1.position_x+40);
            p1.map_x=p1.map_x+1;
        }
    if(judgeblock1())
        {
            map[p1.map_x][p1.map_y]=0;
            Score-=10;
        }
        if(judgemoney1())
        {
            map[p1.map_x][p1.map_y]=0;
            Score+=1;
        }
        if(judgeblood1())
        {
            map[p1.map_x][p1.map_y]=0;
            Score+=2;
        }
}
void MainWindow::Up1()
{
    if(map[p1.map_x][p1.map_y-1]!=1)
        if(p1.map_y>0)
        {
            p1.setdir(p1.UP);
            p1.setposition_y(p1.position_y-40);
            p1.map_y=p1.map_y-1;
        }
    if(judgeblock1())
        {
            map[p1.map_x][p1.map_y]=0;
            Score-=10;
        }
        if(judgemoney1())
        {
            map[p1.map_x][p1.map_y]=0;
            Score+=1;
        }
        if(judgeblood1())
        {
            map[p1.map_x][p1.map_y]=0;
            Score+=2;
        }

}
void MainWindow::Down1()
{
    if(map[p1.map_x][p1.map_y+1]!=1)
        if(p1.map_y<19)
        {
            p1.setdir(p1.DOWN);
            p1.setposition_y(p1.position_y+40);
            p1.map_y=p1.map_y+1;
        }
    if(judgeblock1())
        {
            map[p1.map_x][p1.map_y]=0;
            Score-=10;
        }
        if(judgemoney1())
        {
            map[p1.map_x][p1.map_y]=0;
            Score+=1;
        }
        if(judgeblood1())
        {
            map[p1.map_x][p1.map_y]=0;
            Score+=2;
        }
}

void MainWindow::Left2()
{
    if(map[p2.map_x-1][p2.map_y]!=1)
        if(p2.map_x>0)
        {
            p2.setdir(p2.LEFT);
            p2.setposition_x(p2.position_x-40);
            p2.map_x=p2.map_x-1;
        }

    if(judgeblock2())
        {
            map[p2.map_x][p2.map_y]=0;
            Score-=10;
        }
        if(judgemoney2())
        {
            map[p2.map_x][p2.map_y]=0;
            Score+=1;
        }
        if(judgeblood2())
        {
            map[p2.map_x][p2.map_y]=0;
            Score+=2;
        }
}
void MainWindow::Right2()
{
    if(map[p2.map_x+1][p2.map_y]!=1)
        if(p2.map_x<29)
        {
            p2.setdir(p2.RIGHT);
            p2.setposition_x(p2.position_x+40);
            p2.map_x=p2.map_x+1;
        }
    if(judgeblock2())
        {
            map[p2.map_x][p2.map_y]=0;
            Score-=10;
        }
        if(judgemoney2())
        {
            map[p2.map_x][p2.map_y]=0;
            Score+=1;
        }
        if(judgeblood2())
        {
            map[p2.map_x][p2.map_y]=0;
            Score+=2;
        }
}
void MainWindow::Up2()
{
    if(map[p2.map_x][p2.map_y-1]!=1)
        if(p2.map_y>0)
        {
            p2.setdir(p2.UP);
            p2.setposition_y(p2.position_y-40);
            p2.map_y=p2.map_y-1;
        }
    if(judgeblock2())
        {
            map[p2.map_x][p2.map_y]=0;
            Score-=10;
        }
        if(judgemoney2())
        {
            map[p2.map_x][p2.map_y]=0;
            Score+=1;
        }
        if(judgeblood2())
        {
            map[p2.map_x][p2.map_y]=0;
            Score+=2;
        }
}
void MainWindow::Down2()
{
    if(map[p2.map_x][p2.map_y+1]!=1)
        if(p2.map_y>0)
        {
            p2.setdir(p2.DOWN);
            p2.setposition_y(p2.position_y+40);
            p2.map_y=p2.map_y+1;
        }
    if(judgeblock2())
        {
            map[p2.map_x][p2.map_y]=0;
            Score-=10;
        }
        if(judgemoney2())
        {
            map[p2.map_x][p2.map_y]=0;
            Score+=1;
        }
        if(judgeblood2())
        {
            map[p2.map_x][p2.map_y]=0;
            Score+=2;
        }
}

void MainWindow::Restart()
{

    flag=0;
}

bool MainWindow::WIN()
{
   //0表示空，1表示墙，2表示地刺，3表示金币，4表示血包，5表示出口1,6表示出口2，7入口1,8入口2
            if(map[p1.map_x][p1.map_y]==5&&map[p2.map_x][p2.map_y]==6)
                return true;

   return false;
}
bool MainWindow::LOSE()
{
    if(p1.blood==0||p2.blood==0)
        return true;
    else
        return false;
}

//return true 表示碰到;  return false 表示没有碰到
bool MainWindow::judgewall1()
{
    if(map[p1.map_x][p1.map_y]!=1)
        return true;
    else
        return false;
}
bool MainWindow::judgewall2()
{
    if(map[p2.map_x][p2.map_y]!=1)
        return true;
    else
        return false;
}

bool MainWindow::judgeblock1()//判断地刺
{
    if(map[p1.map_x][p1.map_y]==2)
        return true;
    else
        return false;
}
bool MainWindow::judgeblock2()
{
    if(map[p2.map_x][p2.map_y]==2)
        return true;
    else
        return false;
}

bool MainWindow::judgemoney1()
{
    if(map[p1.map_x][p1.map_y]==3)
        return true;
    else
        return false;
}
bool MainWindow::judgemoney2()
{
    if(map[p2.map_x][p2.map_y]==3)
        return true;
    else
        return false;
}

bool MainWindow::judgeblood1()
{
    if(map[p1.map_x][p1.map_y]==4)
        return true;
    else
        return false;
}
bool MainWindow::judgeblood2()
{
    if(map[p2.map_x][p2.map_y]==4)
        return true;
    else
        return false;
}
