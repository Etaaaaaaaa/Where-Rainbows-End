#include "introscene.h"
#include<qpainter.h>
#include "mypushbutton.h"
#include<mainwindow.h>
#include<ReadyScene.h>

Introscene::Introscene(QWidget *parent) : QMainWindow(parent)
{
    this->setFixedSize(1200,800);
    this->setWindowIcon(QPixmap(":/res/icon.png"));

    //设置标题

    this->setWindowTitle("Where Rainbows End");

}

void Introscene::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap startpage;
    startpage.load(":/res/intropage.png");
     painter.drawPixmap(0,0,this->width(),this->height(),startpage);
      Mypushbutton * backbtn = new Mypushbutton(":/res/backbutton.png");
      connect(backbtn,&Mypushbutton::clicked,this,&Introscene::hide);
       Readyscene *w=new Readyscene;
        w->move(500,200);
      connect(backbtn,&Mypushbutton::clicked,w,&MainWindow::show);
        backbtn->move(800,640);
        backbtn->setParent(this);
        backbtn->show();

}
