#include "plotscene.h"
#include<qpainter.h>
#include<mypushbutton.h>
#include<levelpage.h>

Plotscene::Plotscene(QWidget *parent) : QMainWindow(parent)
{
    setFixedSize(1200,800);
    this->setWindowIcon(QPixmap(":/res/icon.png"));

    //设置标题
    this->setWindowTitle("Where Rainbows End");
}

void Plotscene::paintEvent(QPaintEvent *)
{

    QPainter painter(this);
    QPixmap plot;
    plot.load(":/res/p1.png");
    painter.drawPixmap(0,0,this->width(),this->height(),plot);
    Mypushbutton * next = new Mypushbutton(":/res/nextbutton.png");
    Levelpage *l=new Levelpage;
    l->move(500,200);

      connect(next,&Mypushbutton::clicked,this,&Plotscene::hide);
      connect(next,&Mypushbutton::clicked,l,&Levelpage::show);
      next->setParent(this);
      next->move(984,696);
      next->show();






}
