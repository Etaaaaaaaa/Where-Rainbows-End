#include "ReadyScene.h"
#include <QPainter>
#include<mypushbutton.h>
#include<mainwindow.h>
#include<introscene.h>
#include<qsound.h>
#include<plotscene.h>

Readyscene::Readyscene(QWidget *parent) : QMainWindow(parent)
{
 this->setFixedSize(1200,800);
    //设置图标
        this->setWindowIcon(QPixmap(":/res/icon.png"));

        //设置标题
        this->setWindowTitle("Where Rainbows End");

}

void Readyscene::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap startpage;
    startpage.load(":/res/homepic.png");
     painter.drawPixmap(0,0,this->width(),this->height(),startpage);
     Mypushbutton * startBtn = new Mypushbutton(":/res/startbutton.png");
     startBtn->move(820,460);
      Mypushbutton * introBtn = new Mypushbutton(":/res/introbutton.png");
      introBtn->move(840,640);

Plotscene*m=new Plotscene;
m->move(500,200);
Introscene *i=new Introscene;
i->move(500,200);

 connect(startBtn,&Mypushbutton::clicked,this,&Readyscene::hide);
 connect(introBtn,&Mypushbutton::clicked,this,&Readyscene::hide);
connect(startBtn,&Mypushbutton::clicked,m,&Plotscene::show);
connect(introBtn,&Mypushbutton::clicked,i,&Introscene::show);

    startBtn->setParent(this);
introBtn->setParent(this);
    startBtn->show();
    introBtn->show();


}
