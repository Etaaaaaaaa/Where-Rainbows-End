#ifndef BLUE_H
#define BLUE_H
#include<QPaintEvent>
#include<QPainter>

class blue
{
public:
    blue(int x,int y);
    int position_x;
    int position_y;
    void setposition_x(int x);
    void setposition_y(int y);
    int blood;
    void setblood(int blood);
    int state;
    void setstate(int state);
    int map_x;
    int map_y;
    int dir;
    enum DIRECTION{DOWN,UP,LEFT,RIGHT};
    void setdir(int dir);
};

#endif // BLUE_H
