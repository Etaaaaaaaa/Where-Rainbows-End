#include "mypushbutton.h"
#include<QDebug>


Mypushbutton::Mypushbutton(QString normalImg)
{
    this-> normalImgPath = normalImg;
     QPixmap pixmap;
    pixmap.load(normalImgPath);

     this->setFixedSize( pixmap.width(), pixmap.height() );
        //设置不规则图片的样式表
     this->setStyleSheet("QPushButton{border:0px;}");
        //设置图标
     this->setIcon(pixmap);
        //设置图标大小
     this->setIconSize(QSize(pixmap.width(),pixmap.height()));


}
