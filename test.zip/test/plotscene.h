#ifndef PLOTSCENE_H
#define PLOTSCENE_H

#include <QMainWindow>
#include <QObject>

class Plotscene : public QMainWindow
{
    Q_OBJECT
public:
    explicit Plotscene(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *);


signals:

};

#endif // PLOTSCENE_H
