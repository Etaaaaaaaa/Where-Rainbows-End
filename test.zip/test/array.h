#ifndef ARRAY_H
#define ARRAY_H


class Array
{
public:
    Array(int m);
    int m;
    int a[30][20];


};

#endif // ARRAY_H
