#ifndef READYSCENE_H
#define READYSCENE_H

#include <QMainWindow>
#include <QPainter>

class Readyscene : public QMainWindow
{
    Q_OBJECT
public:
    explicit Readyscene(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *);


signals:

};

#endif // READYSCENE_H
