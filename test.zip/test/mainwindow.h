#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    int Score=0;
    int map_n=0;
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void paintEvent(QPaintEvent *);
    void keyPressEvent(QKeyEvent *event);
    void set1();
    void set2();
    void set3();


        void Right1();
        void Left1();
        void Up1();
        void Down1();

        void Right2();
        void Left2();
        void Up2();
        void Down2();

        void Restart();//复位

        bool WIN();//判断是否赢了
        bool LOSE();//判断是否输了

        bool judgemoney1();
        bool judgemoney2();

        bool judgeblood1();
        bool judgeblood2();

        bool judgeblock1();
        bool judgeblock2();

        bool judgewall1();
        bool judgewall2();


signals:


private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
