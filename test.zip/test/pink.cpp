#include "pink.h"
#include<QPainter>

pink::pink()
{

}

pink::pink(int x, int y)
{
    this->position_x=x;
    this->position_y=y;
    this->setblood(3);
}

void pink::setposition_x(int x)
{
    this->position_x=x;
}

void pink::setposition_y(int y)
{
    this->position_y=y;
}

void pink::setdir(int dir)
{
    this->dir=dir;
}

void pink::setblood(int blood)
{
    this->blood=blood;
}

void pink::setstate(int state)
{
    this->state=state;
}
