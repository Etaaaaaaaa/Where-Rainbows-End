#ifndef MYPUSHBUTTON_H
#define MYPUSHBUTTON_H

#include <QPushButton>

class Mypushbutton : public QPushButton
{
    Q_OBJECT
public:
    explicit Mypushbutton(QWidget *parent = nullptr);
    Mypushbutton(QString normalImg);
    QString normalImgPath;

signals:

};

#endif // MYPUSHBUTTON_H
