#include "overscene.h"
#include"mypushbutton.h"
#include<qpainter.h>
#include<levelpage.h>
#include<ReadyScene.h>
#include<qlabel.h>

void Overscene::seto()
{
    this->v=1;
}

void Overscene::setc()
{
    this->v=0;
}


Overscene::Overscene(QWidget *parent) : QMainWindow(parent)
{
    setFixedSize(800,600);
    this->setWindowIcon(QPixmap(":/res/icon.png"));

    //设置标题
    this->setWindowTitle("Where Rainbows End");

}

void Overscene::paintEvent(QPaintEvent *)
{

    QPainter painter(this);
    QPixmap a;
    QPixmap t;
    QPixmap u;
    if(v==1)
    {
        a.load(":/res/overpage.png");
        a.scaled(400,300);
        painter.drawPixmap(0,0,this->width(),this->height(),a);
    }
    if(v==0)
    {
        a.load(":/res/conpage.png");
        a.scaled(400,300);
        painter.drawPixmap(0,0,this->width(),this->height(),a);

    }
    //480,200 540,200

    int m= score/10;
    int n= score%10;

    if(m==1)
        t.load(":/res/1.png");
    if(m==2)
        t.load(":/res/2.png");
    if(m==3)
        t.load(":/res/3.png");
    if(m==4)
        t.load(":/res/4.png");
    if(m==5)
        t.load(":/res/5.png");
    if(m==6)
        t.load(":/res/6.png");
    if(m==7)
        t.load(":/res/7.png");
    if(m==8)
        t.load(":/res/8.png");
    if(m==9)
        t.load(":/res/9.png");
    painter.drawPixmap(480,200,t.width(),t.height(),t);


    switch(n)
    {
    case 1:
          u.load(":/res/1.png");
         break;
    case 0:
          u.load(":/res/0.png");
         break;
    case 2:
          u.load(":/res/2.png");
         break;
    case 3:
          u.load(":/res/3.png");
         break;
    case 4:
          u.load(":/res/4.png");
         break;
    case 5:
          u.load(":/res/5.png");
         break;
    case 6:
          u.load(":/res/6.png");
         break;
    case 7:
          u.load(":/res/7.png");
         break;
    case 8:
          u.load(":/res/8.png");
         break;
    case 9:
          u.load(":/res/9.png");
         break;



    }

      painter.drawPixmap(540,200,u.width(),u.height(),u);


   Mypushbutton * back = new Mypushbutton(":/res/backbutton.png");
    Mypushbutton * restart = new Mypushbutton(":/res/restartbutton.png");
    Levelpage *l=new Levelpage;
    Readyscene *r =new Readyscene;
    l->move(500,200);
    r->move(500,200);
    connect(back,&Mypushbutton::clicked,this,&Overscene::hide);
    connect(back,&Mypushbutton::clicked,r,&Readyscene::show);
    connect(restart,&Mypushbutton::clicked,this,&Overscene::hide);
    connect(restart,&Mypushbutton::clicked,l,&Levelpage::show);
      back->setParent(this);
      back->move(200,300);
      back->show();
      restart->setParent(this);
      restart->move(200,400);
      restart->show();

}
