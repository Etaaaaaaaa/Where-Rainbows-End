#ifndef OVERSCENE_H
#define OVERSCENE_H

#include <QMainWindow>
#include <QWidget>
#include<qlabel.h>

class Overscene : public QMainWindow
{
    Q_OBJECT
public:
    int score;
    void seto();
    void setc();
    int v;

    explicit Overscene(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *);

signals:

};

#endif // OVERSCENE_H
