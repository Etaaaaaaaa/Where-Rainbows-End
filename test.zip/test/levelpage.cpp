#include "levelpage.h"
#include<qpainter.h>
#include<mypushbutton.h>
#include<mainwindow.h>

Levelpage::Levelpage(QWidget *parent) : QMainWindow(parent)
{

    setFixedSize(1200,800);
    this->setWindowIcon(QPixmap(":/res/icon.png"));

    //设置标题

    this->setWindowTitle("Where Rainbows End");

}

void Levelpage::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap startpage;
    startpage.load(":/res/levelpage.png");
     painter.drawPixmap(0,0,this->width(),this->height(),startpage);

      Mypushbutton * button1 = new Mypushbutton(":/res/button1.png");
      Mypushbutton * button2 = new Mypushbutton(":/res/button2.png");
      Mypushbutton * button3 = new Mypushbutton(":/res/button3.png");
      Mypushbutton * button4 = new Mypushbutton(":/res/button4.png");
      Mypushbutton * button5 = new Mypushbutton(":/res/button5.png");
      Mypushbutton * button6 = new Mypushbutton(":/res/button6.png");
      Mypushbutton * button7 = new Mypushbutton(":/res/button7.png");
      Mypushbutton * button8 = new Mypushbutton(":/res/button8.png");
      Mypushbutton * button9 = new Mypushbutton(":/res/button9.png");
      Mypushbutton * button10 = new Mypushbutton(":/res/button10.png");

      connect(button1,&Mypushbutton::clicked,this,&Levelpage::hide);
      connect(button2,&Mypushbutton::clicked,this,&Levelpage::hide);
      connect(button3,&Mypushbutton::clicked,this,&Levelpage::hide);
      connect(button4,&Mypushbutton::clicked,this,&Levelpage::hide);
      connect(button5,&Mypushbutton::clicked,this,&Levelpage::hide);
      connect(button6,&Mypushbutton::clicked,this,&Levelpage::hide);
      connect(button7,&Mypushbutton::clicked,this,&Levelpage::hide);
      connect(button8,&Mypushbutton::clicked,this,&Levelpage::hide);
      connect(button9,&Mypushbutton::clicked,this,&Levelpage::hide);
      connect(button10,&Mypushbutton::clicked,this,&Levelpage::hide);

       MainWindow *w=new MainWindow;
       w->move(500,200);

      connect(button1,&Mypushbutton::clicked,w,&MainWindow::show);
      connect(button2,&Mypushbutton::clicked,w,&MainWindow::show);
      connect(button3,&Mypushbutton::clicked,w,&MainWindow::show);
      connect(button4,&Mypushbutton::clicked,w,&MainWindow::show);
      connect(button5,&Mypushbutton::clicked,w,&MainWindow::show);
      connect(button6,&Mypushbutton::clicked,w,&MainWindow::show);
      connect(button7,&Mypushbutton::clicked,w,&MainWindow::show);
      connect(button8,&Mypushbutton::clicked,w,&MainWindow::show);
      connect(button9,&Mypushbutton::clicked,w,&MainWindow::show);
      connect(button10,&Mypushbutton::clicked,w,&MainWindow::show);

      connect(button1,&Mypushbutton::clicked,w,&MainWindow::set1);
      connect(button2,&Mypushbutton::clicked,w,&MainWindow::set2);
      connect(button3,&Mypushbutton::clicked,w,&MainWindow::set3);
      connect(button4,&Mypushbutton::clicked,w,&MainWindow::set3);
      connect(button5,&Mypushbutton::clicked,w,&MainWindow::set3);
      connect(button6,&Mypushbutton::clicked,w,&MainWindow::set3);
      connect(button7,&Mypushbutton::clicked,w,&MainWindow::set3);
      connect(button8,&Mypushbutton::clicked,w,&MainWindow::set3);
      connect(button9,&Mypushbutton::clicked,w,&MainWindow::set3);
      connect(button10,&Mypushbutton::clicked,w,&MainWindow::set3);



       button1->move(75,208);
       button1->setParent(this);
       button1->show();
       button2->move(307,208);
       button2->setParent(this);
       button2->show();
       button3->move(540,208);
       button3->setParent(this);
       button3->show();
       button4->move(780,208);
       button4->setParent(this);
       button4->show();
       button5->move(996,208);
       button5->setParent(this);
       button5->show();
       button6->move(75,480);
       button6->setParent(this);
       button6->show();
       button7->move(307,480);
       button7->setParent(this);
       button7->show();
       button8->move(540,480);
       button8->setParent(this);
       button8->show();
       button9->move(780,480);
       button9->setParent(this);
       button9->show();
       button10->move(996,480);
       button10->setParent(this);
       button10->show();



}
